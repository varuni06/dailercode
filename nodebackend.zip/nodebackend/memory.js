var os = require('os');

// console.log(os.cpus());
console.log(os.totalmem());
console.log(os.freemem())