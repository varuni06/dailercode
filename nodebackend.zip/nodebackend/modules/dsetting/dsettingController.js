const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const dsettingConfig = require('./dsettingConfig');
const dsettingSch = require('./dsettingSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const dsettingController = {};

dsettingController.getdsetting = async (req, res, next) => {
  try {
    const names = await dsettingSch.find().select('id key value');
    return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, dsettingConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};



dsettingController.getdsettingDetail = async (req, res, next) => {
  console.log(req.query.id)
  const menu = await dsettingSch.findById(req.query.id, { id:1, key:1,  value :1 });
  console.log(menu);
  return otherHelper.sendResponse(res, httpStatus.OK, true, menu, null,dsettingConfig.namesGet, null, 'Dsetting Not Found');
};


dsettingController.postdsetting = async (req, res, next) => {
  try {
    const theme = req.body;
    theme.updated_by = req.user.id;
    theme.updated_at = Date.now();
    if (theme && theme.id !== 0) {
      const update = await dsettingSch.findByIdAndUpdate({ _id: theme._id }, { $set: theme }, { new: true });
      return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, dsettingConfig.dsettingSave, null);
    } else {
      let newTheme = new dsettingSch(theme);
      let saved = await newTheme.save();
      return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, dsettingConfig.dsettingSave, null);
    }
  } catch (err) {
    next(err);
  }
};

// dsettingController.updatedsetting = async (req, res, next) => {
//   try {
//     const id = req.query.id;
//     const updateFields = req.body;
//     updateFields.updated_at = new Date();

//     const updatedSetting = await dsettingSch.findByIdAndUpdate(
//       id,
//       { $set: updateFields },
//       { new: true }
//     );

//     if (!updatedSetting) {
//       return otherHelper.sendResponse(res,httpStatus.NOT_FOUND,false,null,dsettingConfig.settingNotFound,null
//       );
//     }

//     return otherHelper.sendResponse(res,httpStatus.OK,true,updatedSetting,null,dsettingConfig.settingUpdate,null
//     );
//   } catch (err) {
//     next(err);
//   }
// };

dsettingController.Deletedsetting = async (req, res, next) => {
  try {
    const id = req.query.id;
    const theme = await dsettingSch.findByIdAndRemove(
      id,
      {
        $set: {
          is_deleted: true,
          deleted_at: new Date(),
        },
      });
    return otherHelper.sendResponse(res,httpStatus.OK,true,theme,null,dsettingConfig.dsettingDelete,null
    );
  } catch (err) {
    next(err);
  }
};


dsettingController.Searchsetting = async (req, res, next) => {
  const setting = await dsettingSch.find({
    $or: [{ key : { $regex: req.query.key } }],
  });
  return otherHelper.sendResponse(res, httpStatus.OK, true, setting, null, dsettingConfig.namesGet, null, 'Module Not Found');
}



module.exports = dsettingController;
