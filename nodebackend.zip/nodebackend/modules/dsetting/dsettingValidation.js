const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const dsettingConfig = require('./dsettingConfig');
const dsettingSch = require('./dsettingSchema');
const dsettingValidation = {};

dsettingValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [

    {
      field: 'key',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'value',
      sanitize: {
        trim: true,
      },
    },
   
  ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

dsettingValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: dsettingConfig.validate.isMongoID,
        },
      ],
    },
   
    {
      field: 'key',
      validate: [
        {
          condition: 'IsEmpty',
          msg: dsettingConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: dsettingConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    {
      field: 'value',
      validate: [
        {
          condition: 'IsEmpty',
          msg: dsettingConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: dsettingConfig.validate.isLength300,
          option: { min: 2, max: 300 },
        },
      ],
    },
    
  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, key: data.key }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await dsettingSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, theme_key: 'dsetting already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, dsettingConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = dsettingValidation;
