const mongoose = require('mongoose');
const schema = mongoose.Schema;

const dsettingSchema = new schema({
  id: { type: Number },
  key: { type: String},
  value: { type: String },
  updated_at: { type: Date },
  created_by: { type: Date },
  deleted_at:{type:Date},
  is_deleted:{type:Boolean},
});

module.exports = dsetting = mongoose.model('dsettings', dsettingSchema);