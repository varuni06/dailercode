module.exports = {
  validate: {
    isEmpty: 'This field is required!',
    isLength50: 'This field length should be between 2 to 50!',
    isLength300: 'This field length should be between 2 to 300!',
    isLength: 'This field length should be minimum 2!',
    isMongoID: 'This field is invalid',
    empty: 'This field is required!',
    length: 'Length should be between 2 to 500',
    unique: 'This field should be unique',
    duplicateKey: 'The key you have provided is already taken. Please enter another key',
  },
  errorIn: {
    inputErrors: 'Invalid Inputs',
  },
  templateSave: 'Template saved successful!',
  templateGet: 'Template get successful!',
  namesGet: 'Template Names get successful!',
  templateDelete: 'Template deleted successfully!',
  templateNotFound: 'Template Not Found',
  get: 'Slider get successful!',
  save: 'Slider saved successful!',
  delete: 'Slider delete successful!',
};
