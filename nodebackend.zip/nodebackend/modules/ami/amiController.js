const express = require('express');
const app = express();
const AsteriskAGIHelper = require('./AsteriskAGIHelper');
const amiController = {};


const initialSipCall = async (userId) => {
  const response = await AsteriskAGIHelper.InitialSIPCallPlace(userId);
  // console.log("checking response",response)

  
  let logicStatus;
  if (response.success === true) {
    logicStatus = "true";
  } else {
    logicStatus = "false";
  }

  response.msg_array = {};
  response.msg_array.logic_status = logicStatus;
  response.msg_array.title = "Initial sip call";

  let dial_response;
  if (response.success) {
    dial_response = {
      success: true,
      msg: response.msg,
      data: response.data,
      conferance_channel_id: response.conferance_channel_id.replace('SIP/', ''),
      msg_array: response.msg_array
    };
  } else {
    dial_response = {
      success: false,
      msg: response.msg,
      data: response.data,
      conferance_channel_id: 0,
      msg_array: response.msg_array
    };
  }
  return dial_response;
};

amiController.SipCall = async (req, res) => {
  const userId = req.query.id;
  const response = await initialSipCall(userId);
  res.json(response);
};

module.exports = amiController;