const DUserDialerSettings = require('../userdailersetting/userdailersettingSchema');
const dseetingschema = require("../dsetting/dsettingSchema")
const AGI_AsteriskManager = require('./AGI_AsteriskManager'); 


async function GetAstiriskSettings() {
  var asteriskip = "192.168.0.248";
  var manageruser = "mayur";
  var managerpass = "mayur";
  var outboundContext = "5038";
  var outboundChannel = true;
  // var asteriskSettings = dseetingschema.findOne(asteriskip,manageruser,managerpass,outboundContext,outboundChannel);

  const asteriskSettings = [
    { key: "asteriskip", value: asteriskip },
    { key: "manageruser", value: manageruser },
    { key: "managerpass", value: managerpass },
    { key: "outboundContext", value: outboundContext },
    { key: "outboundChannel", value: outboundChannel.toString() }
  ];
  for (const rawdata of asteriskSettings) {
    if (rawdata.key === "asteriskip") {
      asteriskip = rawdata.value;
    } else if (rawdata.key === "manageruser") {
      manageruser = rawdata.value;
    } else if (rawdata.key === "managerpass") {
      managerpass = rawdata.value;
    } else if (rawdata.key === "outboundContext") {
      outboundContext = rawdata.value;
    } else if (rawdata.key === "outboundChannel") {
      outboundChannel = (rawdata.value === "true");
    }
  }

  const data = {
    strHost: asteriskip,
    strUser: manageruser,
    strSecret: managerpass,
    strContext: outboundContext,
    strChannel: outboundChannel
  };
  return data;
}


async function InitialSIPCallPlace(user_id) {
  try {
    const userSettings = await DUserDialerSettings.findOne({ user_id });
  
    if (userSettings) {
      const user_group = userSettings.group_no;
      const user_extension = userSettings.extention;
      const user_extension_number = userSettings.extention;
  
      let sip_call_already_running;
      if (userSettings.agent_conferance_channel_id == 2) {
        sip_call_already_running = false;
      } else {
        sip_call_already_running = true;
      }
      console.log("checkinggggg sip call running or not ", sip_call_already_running )
    
      if (!sip_call_already_running) {
        const data_initialcall = await InitialsingleCallPlace(
          user_group,
          user_extension,
          user_extension_number,
          user_id
        );
  
        if (data_initialcall.success) {
          const call_ref_no = data_initialcall.call_ref_no;
          const data = {
            success: true,
            msg: data_initialcall.msg,
            data: data_initialcall,
            msg_array: data_initialcall.msg_array,
            conferance_channel_id: call_ref_no,
          };
  
          return data;
        } else {
          const data = {
            success: false,
            msg: data_initialcall.msg,
            data: data_initialcall,
            msg_array: data_initialcall.msg_array,
          };
  
          return data;
        }
      } else {
        const msg_array = {
          msg: "Initial Call Already Running",
          initialsipcall_channel_id: userSettings.agent_conferance_channel_id,
        };
        const data = {
          success: true,
          msg: "Initial Call Already Running",
          data: null,
          msg_array: msg_array,
          conferance_channel_id: userSettings.agent_conferance_channel_id,
        };
  
        return data;
      }
    } else {
      const data = {
        success: false,
        msg: "User settings not found",
        data: null,
        msg_array: null,
      };
  
      return data;
    }
  } catch (error) {
    console.error('Error during InitialSIPCallPlace:', error);
    const data = {
      success: false,
      msg: 'Error during InitialSIPCallPlace',
      data: null,
      msg_array: null,
    };
    return data;
  }
}


async function InitialsingleCallPlace(user_group, user_extention, user_extention_number, userid) {
  const responce = await asterisk_sipinitial_originate_action(user_group, user_extention, user_extention_number);

  if (responce['success']) {
    if (responce['data']['Events'][2]['Event'] == 'Newchannel') {
      const agent_conferance_channel_id = responce['data']['Events'][2]['Channel'];

      const userSettings = await DUserDialerSettings.findOne({ user_id: userid });

      const data = {
        agent_conferance_channel_id: agent_conferance_channel_id,
      };
      await userSettings.update(data);

      responce['msg_array']['initialcall_channel_no'] = agent_conferance_channel_id;

      const responseData = {
        success: true,
        msg: responce['msg'] + "channel-" + agent_conferance_channel_id,
        data: responce,
        call_ref_no: agent_conferance_channel_id,
        msg_array: responce['msg_array'],
      };

      return responseData;
    } else {
      responce['msg_array']['call_status'] = "Might be call Failure";
      const data = {
        success: false,
        msg: responce['msg'] + "Might be call Failure",
        data: responce,
        msg_array: responce['msg_array'],
      };

      return data;
    }
  } else {
    const data = {
      success: false,
      msg: responce['msg'],
      data: responce,
      msg_array: responce['msg_array'],
    };

    return data;
  }
}



// async function asterisk_sipinitial_originate_action(user_group, user_extention, user_extention_number) {
//   const settings = await GetAstiriskSettings();
//   const strHost = settings.strHost; //'192.168.0.169';
//   const strUser = settings.strUser; //'mayur';
//   const strSecret = settings.strSecret; //'mayur';
//   // const res = await GetAstiriskSettings(strHost, strUser, strSecret);

//   const res =  await AGI_AsteriskManager.Connect(strHost, strUser, strSecret);
 
//   if (res.success) {
    
//     const strWaitTime = 45;
//     const strPriority = 1;
//     const strMaxRetry = "2";
//     const strCallerId = user_extention_number + "0000";
//     const strChannel = "SIP/" + user_extention;
//     const conference_no = user_extention_number + user_extention_number;

//     console.log("going to originate function ");

//     const r = await AGI_AsteriskManager.Originate(
//       strChannel,
//       user_extention_number,
//       user_group,
//       strPriority,
//       '',
//       '',
//       '',
//       strCallerId,
//       'method=0,conf=' + conference_no,
//       'session_call',
//       'Async',
//       ''
//     );
//     console.log("back in originate action ")
//     const rec_msg = "";
//     const msg_array = { msg: r && r.Message ? r.Message : 'Unknown error' };

//     const data = {
//       success: r && r.Response === "Success",
//       msg: r && r.Message ? r.Message : 'Unknown error',
//       data: r,
//       msg_array: msg_array,
//       };
//       // AGI_AsteriskManager.disconnect();
//       return data;
//   } else {
//     const msg_array ={ msg: res && res.message ? res.message : 'Unknown error' };
//     const data = {
//       success: false,
//       msg:  res && res.message ? res.message : 'Unknown error',
//       data: null,
//       msg_array: msg_array,
//     };
//     console.log("its checked complete dataaaa",data)
//    return data;
   
//   }
// }



// async function asterisk_sipinitial_originate_action(user_group, user_extention, user_extention_number) {
//   const settings = await GetAstiriskSettings();
//   const strHost = settings.strHost; //'192.168.0.169';
//   const strUser = settings.strUser; //'mayur';
//   const strSecret = settings.strSecret; //'mayur';
//   // const res = await GetAstiriskSettings(strHost, strUser, strSecret);

//   const res =  await AGI_AsteriskManager.Connect(strHost, strUser, strSecret);
 
//   if (res.success) {
    
//     const strWaitTime = 45;
//     const strPriority = 1;
//     const strMaxRetry = "2";
//     const strCallerId = user_extention_number + "0000";
//     const strChannel = "SIP/" + user_extention;
//     const conference_no = user_extention_number + user_extention_number;

//     console.log("going to originate function ");

//     const r = await AGI_AsteriskManager.Originate(
//       strChannel,
//       user_extention_number,
//       user_group,
//       strPriority,
//       '',
//       '',
//       '',
//       strCallerId,
//       'method=0,conf=' + conference_no,
//       'session_call',
//       'Async',
//       ''
//     );

//     const rec_msg = "";
//     const msg_array = { msg: r && r.Message ? r.Message : 'Unknown error' };

//     const data = {
//       success: r && r.Response === "Success",
//       msg: r && r.Message ? r.Message : 'Unknown error',
//       data: r,
//       msg_array: msg_array,
//       };
//     // AGI_AsteriskManager.disconnect();
//       return data;
//   } else {
//     const msg_array ={ msg: res && res.message ? res.message : 'Unknown error' };
//     const data = {
//       success: false,
//       msg:  res && res.message ? res.message : 'Unknown error',
//       data: null,
//       msg_array: msg_array,
//     };
//     console.log("its checked complete dataaaa",data)
//    return data;
   
//   }
// }



async function asterisk_sipinitial_originate_action(user_group, user_extention, user_extention_number) {
  const settings = await GetAstiriskSettings();
  const strHost = settings.strHost;
  const strUser = settings.strUser;
  const strSecret = settings.strSecret;

  const res = await AGI_AsteriskManager.Connect(strHost, strUser, strSecret);

  if (res.success) {
    const strWaitTime = 45;
    const strPriority = 1;
    const strMaxRetry = "2";
    const strCallerId = user_extention_number + "0000";
    const strChannel = "SIP/" + user_extention;
    const conference_no = user_extention_number + user_extention_number;

    console.log("going to originate function ");

    const r = await AGI_AsteriskManager.Originate(
      strChannel,
      user_extention_number,
      user_group,
      strPriority,
      '',
      '',
      '',
      strCallerId,
      'method=0,conf=' + conference_no,
      'session_call',
      'Async',
      ''
    );

    if (r && r.Response === 'Success') {
      const waitResponse = await AGI_AsteriskManager.waitResponseWithEvents(true, 2, res.data);
      console.log("checking the connectionnnnn waitResponse <<<<<<_____________________>>>>>>>>>>>>>>>>>>",waitResponse)

      const rec_msg = "";
      const msg_array = { msg: waitResponse && waitResponse.Message ? waitResponse.Message : 'Unknown error' };

      const data = {
        success: waitResponse && waitResponse.Response === "Success",
        msg: waitResponse && waitResponse.Message ? waitResponse.Message : 'Unknown error',
        data: waitResponse,
        msg_array: msg_array,
      };

      // AGI_AsteriskManager.disconnect();
      return data;
    } else {
      const msg_array = { msg: r && r.Message ? r.Message : 'Unknown error' };
      const data = {
        success: false,
        msg: r && r.Message ? r.Message : 'Unknown error',
        data: null,
        msg_array: msg_array,
      };
      console.log("It checked complete data", data);
      return data;
    }
  } else {
    const msg_array = { msg: res && res.message ? res.message : 'Unknown error' };
    const data = {
      success: false,
      msg: res && res.message ? res.message : 'Unknown error',
      data: null,
      msg_array: msg_array,
    };
    console.log("It checked complete data", data);
    return data;
  }
}


module.exports = {
  InitialSIPCallPlace,
  asterisk_sipinitial_originate_action,
};


