
     
      //  connect the socket
      //  $errno = $errstr = NULL;
      //  $this->socket = @fsockopen($this->server, $this->port, $errno, $errstr,1);
 
      //  if($this->socket == false)
      //  {
      //    $log = "Unable to connect to manager {$this->server}:{$this->port} ($errno): $errstr";
      //    $connected = false;
      //  }else{
      //    // read the header
      //    $str = fgets($this->socket);
      //    if($str == false)
      //    {
      //        // a problem.
      //        $log = "Asterisk Manager header not received.";
      //        $connected = false;
      //    }
      //    else
      //    {// login
      //        $res = $this->send_request('login', array('Username'=>$username, 'Secret'=>$secret));
 
      //        if($res['Response'] != 'Success')
      //        {
      //            $this->_logged_in = FALSE;
      //        // $this->log("Failed to login.");
      //            $log = $res['Message'];
      //            $this->disconnect();
      //            $connected = false;
      //        }else{
      //            $log = $res['Message'];
      //            $connected = true;
      //            $this->_logged_in = TRUE;
      //        }
 
      //    }
 
 
 
      //  }
      //    $responce = array(
      //        'success'=>$connected,
      //        'message'=> $log,
      //        'data'=> $this->socket,
      //    );
      //    //print_r($responce);exit;
      //    return $responce;
      //    }
     
     
// /////// will send action to asterisk 
//      function send_request($action, $parameters=array())
//      {
//        $req = "Action: $action\r\n";
//        foreach($parameters as $var=>$val)
//          $req .= "$var: $val\r\n";
//        $req .= "\r\n";
//        ///// below line send call to asterisk
//   //     fwrite($this->socket, $req);
     

// /// add new code here to login to manager with action.
// //  var ami = new require('asterisk-manager')('5038',strHost,strUser,strSecret, true);

//        ami.action({
//       'action': 'login',
//       'Username': 'mayur',
//       'Secret': 'mayur',
      
//     }, function (err, result) {
//       if (err) {
//         console.error(err);
//         res.status(500).send('An error occurred');
//       } else {
//         console.log(result);
//         res.status(200).send(result);
//       }
//     });
//   }


//        if($action == "Originate"){
//         return $this->wait_response_with_events(true,3);
//         //return $this->wait_response_with_waittime(5);
//        }else if($action == "Command"){
 
//          //return $this->wait_response_with_events(true,3,'alloutputs');
//          return $this->wait_response_manager(true);     
//          //return $this->wait_response_with_waittime(5);
 
//        }else if($action == "Status"){        
//            //  return $this->wait_response_with_waittime(5);
//           // return $this->wait_response_manager(true);
//          //if need all records
                 
//          if(empty($parameters)){
//              return $this->wait_response_with_events(true,100);
//          }else{
//              //if need specific record
//              return $this->wait_response_with_events(true,3);
//          }
         
 
//          } else{
//          return $this->wait_response();
//        }
 
//      }




   

    //   const AMI = require('asterisk-manager');
 
    //  const ami = new AMI({
    //    host: strHost,
    //    port: 5038,  // Default AMI port
    //    username: strUser,
    //    password: strSecret,
    //    reconnect: true
    //  });
     

    
  //    ami.on('managerevent', (event) => {
  //     console.log('insidesss-----------');
  //      if (event.event === 'FullyBooted') {
  //        console.log('Connected to Asterisk AMI');
  //        // Perform further actions here
  //        // ...
  //      } else if (event.response === 'Error') {
  //        console.error('Error connecting to Asterisk AMI:', event.message);
  //        // Handle connection error
  //        // ...
  //      }
     
  //      // Handle other responses as needed
  //      // ...
  //    });
     
  //    ami.on('disconnect', () => {
  //      console.log('Disconnected from Asterisk AMI');
  //      // Handle disconnection
  //      // ...
  //    });
     
  //    ami.keepConnected();
  //  } 
   
















  //  ------------------------------------------------------





  //  // amiController.initialSipCall = (req, res) => {
  //   function AstConnect() {
  //     // var ami = new require('asterisk-manager')('5038', '192.168.0.248', 'mayur', 'mayur', true);
  //       console.log(strHost);
  //       const AMI = require('asterisk-manager');
   
  //      const ami = new AMI({
  //        host: 'your_asterisk_host',
  //        port: 5038,  // Default AMI port
  //        username: 'your_username',
  //        password: 'your_password',
  //        reconnect: true
  //      });
       
  //      ami.on('managerevent', (event) => {
  //        if (event.event === 'FullyBooted') {
  //          console.log('Connected to Asterisk AMI');
  //          // Perform further actions here
  //          // ...
  //        } else if (event.response === 'Error') {
  //          console.error('Error connecting to Asterisk AMI:', event.message);
  //          // Handle connection error
  //          // ...
  //        }
       
  //        // Handle other responses as needed
  //        // ...
  //      });
       
  //      ami.on('disconnect', () => {
  //        console.log('Disconnected from Asterisk AMI');
  //        // Handle disconnection
  //        // ...
  //      });
       
  //      ami.keepConnected();
  //    } 
  //    module.exports = AstConnect;
  //    // You can also send specific AMI commands using the "sendAction" method
   
  //      // For example:
  //      // ami.sendAction({
  //      //   Action: 'Ping'
  //      // }, (response) => {
  //      //   // Handle the response
  //      //   // ...
  //      // });

















//  // ------------------------------------



//     // add logic if above all data is not null ----------------done  
//     ami.on('managerevent', (event) => {
//       if (event.event === 'FullyBooted') {
//         console.log('Connected to Asterisk AMI');
    
//       } else if (event.response === 'Error') {
//         console.error('Error connecting to Asterisk AMI:', event.message);
//       }  else if (event.data === null) {
//         console.warn('Received null data from Asterisk AMI is empty ');
//         // Handle the null data condition here
//       } else {
//         // Handle other events or data conditions here
//       }
//     });



















// ---------------------------------------------------------------------------------------------------------
















// const Connect = (strHost, strUser, strSecret) => {
//   const ami = new (require('asterisk-manager'))('5038', strHost, strUser, strSecret, true);
//   ami.keepConnected();

//   // Login to Asterisk action
//   ami.action({
//     'action': 'login',
//     'Username': strUser,
//     'Secret': strSecret
//   }, (response) => {
//     if (response === null) {
//       console.warn('Received null response from Asterisk AMI');
//     } else {
  
//     }
//   });
//   console.log("Moving to call functionm  ");
  // Calling an Asterisk function
  // const Originate = () => {
  //   ami.action({
  //     'action': 'originate',
  //     'channel': 'SIP/1001',
  //     'context': 'csr',
  //     'exten': 1003,
  //     'priority': 1,
  //     'variable': {
  //       'name1': 'value1',
  //       'name2': 'value2'
  //     }
  //   }, (err, res) => {
  //     console.log("callingggggg");
  //     console.log(res);
  //   });
  // };

  // Originate();

//   const Originate = async (
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   ) => {
//     const response = await ami.action({
//       'action': 'originate',
//       'channel': strChannel,
//       'context': 'session_call',
//       'exten': user_extention_number,
//       'priority': strPriority,
//       'callerid': strCallerId,
//       'variable': `method=0,conf=${conference_no}`,
//       'async': 'true'
//     });

//     console.log("callingggggg");
//     console.log(response);
//     return response;
//   };

//   await Originate(
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   );


// };

// module.exports = Connect;



// const Connect = (strHost, strUser, strSecret) => {
//   const ami = new (require('asterisk-manager'))('5038', strHost, strUser, strSecret, true);
//   ami.keepConnected();

//   // Login to Asterisk action
//   ami.action({
//     'action': 'login',
//     'Username': strUser,
//     'Secret': strSecret
//   }, (response) => {
//     if (response === null) {
//       console.warn('Received null response from Asterisk AMI');
//     } else {
  
//     }
//   });
//   console.log("Moving to call functionm  ");
  // Calling an Asterisk function
  // const Originate = () => {
  //   ami.action({
  //     'action': 'originate',
  //     'channel': 'SIP/1001',
  //     'context': 'csr',
  //     'exten': 1003,
  //     'priority': 1,
  //     'variable': {
  //       'name1': 'value1',
  //       'name2': 'value2'
  //     }
  //   }, (err, res) => {
  //     console.log("callingggggg");
  //     console.log(res);
  //   });
  // };

  // Originate();

//   const Originate = async (
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   ) => {
//     const response = await ami.action({
//       'action': 'originate',
//       'channel': strChannel,
//       'context': 'session_call',
//       'exten': user_extention_number,
//       'priority': strPriority,
//       'callerid': strCallerId,
//       'variable': `method=0,conf=${conference_no}`,
//       'async': 'true'
//     });

//     console.log("callingggggg");
//     console.log(response);
//     return response;
//   };

//   await Originate(
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   );


// };

// module.exports = Connect;




// ------------------------------------------------------------------------



// function connect($server=NULL, $username=NULL, $secret=NULL, $port=5038)
//   {
//     // use config if not specified
//     if(is_null($server)) $server = $this->config['asmanager']['server'];
//     if(is_null($username)) $username = $this->config['asmanager']['username'];
//     if(is_null($secret)) $secret = $this->config['asmanager']['secret'];

//     // get port from server if specified
//     if(strpos($server, ':') !== false)
//     {
//       $c = explode(':', $server);
//       $this->server = $c[0];
//       $this->port = $c[1];
//     }
//     else
//     {
//       $this->server = $server;
//       $this->port = $port; //$this->config['asmanager']['port'];
//     }

//     // connect the socket
//     $errno = $errstr = NULL;
//     $this->socket = @fsockopen($this->server, $this->port, $errno, $errstr,1);

//     if($this->socket == false)
//     {
//       $log = "Unable to connect to manager {$this->server}:{$this->port} ($errno): $errstr";
//       $connected = false;
//     }else{
//       // read the header
//       $str = fgets($this->socket);
//       if($str == false)
//       {
//           $log = "Asterisk Manager header not received.";
//           $connected = false;
//       }
//       else
//       {           
//           $res = $this->send_request('login', array('Username'=>$username, 'Secret'=>$secret));

//           if($res['Response'] != 'Success')
//           {
//               $this->_logged_in = FALSE;
//               $log = $res['Message'];
//               $this->disconnect();
//               $connected = false;
//           }else{
//               $log = $res['Message'];
//               $connected = true;
//               $this->_logged_in = TRUE;
//           }

//       }



//     }
//       $responce = array(
//           'success'=>$connected,
//           'message'=> $log,
//           'data'=> $this->socket,
//       );
//       return $responce;
//   }






//-----------------------------sendRequest function   ---------------------
// function sendRequest(action, parameters = {}) {
//   let req = `Action: ${action}\r\n`;
//   for (let varName in parameters) {
//     let value = parameters[varName];
//     req += `${varName}: ${value}\r\n`;
//   }
//   req += '\r\n';
// }
 
//   this.socket.write(req);

//   if (action === 'Originate') {
//     return waitResponseWithEvents(true, 3);
//   } else if (action === 'Command') {
//     return waitResponseManager(true);
//   } else if (action === 'Status') {
//     if (Object.keys(parameters).length === 0) {
//       return waitResponseWithEvents(true, 100);
//     } else {
//       return waitResponseWithEvents(true, 3);
//     }
//   } else {
//     return waitResponse();
//   }
// }





















// async function waitResponseManager(allow_timeout = false) {
//     let timeout = false;
//     const master_output = {
//       Response: null,
//       Message: null,
//       Events: null,
//       Outputs: null,
//     };
  
//     const rl = readline.createInterface({
//       input: process.stdin,
//       output: process.stdout,
//       crlfDelay: Infinity,
//     });
  
//     rl.on('line', (line) => {
//       const buffer = line.trim();
//       if (buffer === '') return;
  
//       let type = null;
//       const parameters = {};
  
//       const a = buffer.indexOf(':');
//       if (a !== -1) {
//         if (Object.keys(parameters).length === 0) {
//           type = buffer.substring(0, a).toLowerCase();
//           if (buffer.substring(a + 2) === 'Follows') {
//             parameters['data'] = '';
//             rl.on('line', (followsLine) => {
//               if (followsLine.startsWith('--END ')) return;
//               parameters['data'] += followsLine;
//             });
//           }
//         } else if (Object.keys(parameters).length === 2) {
//           if (
//             parameters['Response'] &&
//             parameters['Message'] &&
//             parameters['Message'] === 'Command output follows'
//           ) {
//             parameters['data'] = '';
//             rl.on('line', (outputLine) => {
//               if (outputLine === '') return;
//               parameters['data'] += outputLine.replace(/^Output:\s*/, '');
//             });
//             rl.off('line', onLine); // Remove the 'line' listener for further processing
//             return;
//           }
//         }
  
//         const key = buffer.substring(0, a);
//         const value = buffer.substring(a + 2);
//         parameters[key] = value;
//       }
  
//       switch (type) {
//         case '':
//           timeout = allow_timeout;
//           break;
//         case 'event':
//           this.process_event_manager(parameters);
//           break;
//         case 'response':
//         case 'message':
//           break;
//         default:
//           console.log(`Unhandled response packet (${type}) from Manager: ${JSON.stringify(parameters)}`);
//           break;
//       }
  
//       if (type === 'response' || type === 'message') {
//         rl.off('line', onLine); // Remove the 'line' listener for further processing
//         processUserInput(); // Prompt the user for input
//       }
//     });
  
//     rl.on('error', (error) => {
//       console.error('Error occurred in readline interface:', error);
//       // Handle the error as needed
//     });
  
//     function processUserInput() {
//       readLine().then((input) => {
//         // Process the user input here
//         // ...
//         // Update the master_output accordingly
//         // ...
//         rl.close(); // Close the readline interface
//       });
//     }
  
//     return master_output;
//   }












// async function waitResponseManager(allow_timeout = false) {
//   let timeout = false;
//   const master_output = {
//     Response: null,
//     Message: null,
//     Events: null,
//     Outputs: null,
//   };

//   const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout,
//     crlfDelay: Infinity,
//   });

//   const lineListener = (line) => {
//     const buffer = line.trim();
//     if (buffer === '') return;

//     let type = null;
//     const parameters = {};

//     const a = buffer.indexOf(':');
//     if (a !== -1) {
//       if (Object.keys(parameters).length === 0) {
//         type = buffer.substring(0, a).toLowerCase();
//         if (buffer.substring(a + 2) === 'Follows') {
//           parameters['data'] = '';
//           rl.on('line', (followsLine) => {
//             if (followsLine.startsWith('--END ')) return;
//             parameters['data'] += followsLine;
//           });
//         }
//       } else if (Object.keys(parameters).length === 2) {
//         if (
//           parameters['Response'] &&
//           parameters['Message'] &&
//           parameters['Message'] === 'Command output follows'
//         ) {
//           parameters['data'] = '';
//           rl.on('line', (outputLine) => {
//             if (outputLine === '') return;
//             parameters['data'] += outputLine.replace(/^Output:\s*/, '');
//           });
//           rl.off('line', lineListener); // Remove the 'line' listener for further processing
//           return;
//         }
//       }

//       const key = buffer.substring(0, a);
//       const value = buffer.substring(a + 2);
//       parameters[key] = value;
//     }

//     switch (type) {
//       case '':
//         timeout = allow_timeout;
//         break;
//       case 'event':
//         this.process_event_manager(parameters);
//         break;
//       case 'response':
//       case 'message':
//         break;
//       default:
//         console.log(`Unhandled response packet (${type}) from Manager: ${JSON.stringify(parameters)}`);
//         break;
//     }

//     if (type === 'response' || type === 'message') {
//       rl.off('line', lineListener); // Remove the 'line' listener for further processing
//       processUserInput(); // Prompt the user for input
//     }
//   };

//   rl.on('line', lineListener);

//   rl.on('error', (error) => {
//     console.error('Error occurred in readline interface:', error);
//     // Handle the error as needed
//   });

//   function processUserInput() {
//     readLine().then((input) => {
//       // Process the user input here
//       // ...
//       // Update the master_output accordingly
//       // ...
//       rl.close(); // Close the readline interface
//     });
//   }

//   return master_output;
// }











 // ------------Manual Callllll--------------------------------------
  // const Originate = () => {
  //   ami.action({
  //     'action': 'originate',
  //     'channel': 'SIP/1001',
  //     'context': 'csr',
  //     'exten': 1003,
  //     'priority': 1,
  //     'variable': {
  //       'name1': 'value1',
  //       'name2': 'value2'
  //     }
  //   }, (err, res) => {
  //     console.log("callingggggg");
  //     console.log(res);
  //   });
  // };

  // Originate();

 // ------------Auto  Callllll--------------------------------------------------------------
//   const Originate = async (
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   ) => {
//     const response = await ami.action({
//       'action': 'originate',
//       'channel': strChannel,
//       'context': 'session_call',
//       'exten': user_extention_number,
//       'priority': strPriority,
//       'callerid': strCallerId,
//       'variable': `method=0,conf=${conference_no}`,
//       'async': 'true'
//     });

//     console.log("callingggggg");
//     console.log(response);
//     return response;
//   };

//   await Originate(
//     strChannel,
//     user_extention_number,
//     user_group,
//     strPriority,
//     strCallerId,
//     conference_no
//   );
// };








