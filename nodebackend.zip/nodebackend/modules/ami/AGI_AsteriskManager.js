const net = require('net');
const socket = new net.Socket();
const readline = require('readline');
const buffer = require('buffer');

const Connect = async( server =strHost  ,username = strUser, secret = strSecret, port = 5038) => {

    if (server === null) server =strHost ;
    if (username === null) username = strUser;
    if (secret === null) secret = strSecret;
 
    if (server.includes(':')) {
      const [s, p] = server.split(':');
      server = s;
      port = p;
    }
    return new Promise((resolve, reject) => {
      socket.connect(port, server);
  
      socket.on('error', (err) => {
        const log = `Unable to connect to manager ${server}:${port} (${err.code}): ${err.message}`;
        const connected = false;
        const response = {
          success: connected,
          message: log,
          data: socket,
        };
        console.error(log);
        resolve(response);
      });

      socket.on('close', () => {
        console.log('Socket closed');
      });
  
      socket.once('data', async (data) => {
        const header = data.toString();
        if (header === '') {
          const log = 'Asterisk Manager header not received.';
          const connected = false;
          const response = {
            success: connected,
            message: log,
            data: socket,
          };
          console.error("log>>>>>>", log);
          resolve(response);
        }
  
        try {
          const res = await send_request.call(this, 'login', { Username: username, Secret: secret }, socket);
          // console.log("checking the response ",res)
          if (res.Response == 'Success') {
            console.log("response not success fail to login")
            this._logged_in = false;
            const log = res.Message;
            disconnect(socket);
            const connected = false;
            const response = {
              success: connected,
              message: log,
              data: socket,
            };
            console.error(log);
            resolve(response);
          } else {
            console.log("response is success")
            const log = res.Message;
            const connected = true;
            this._logged_in = true;
            const response = {
              success: connected,
              message: log,
              data: socket,
            };
            resolve(response);
          }
        } catch (error) {
          console.error('Error during login:', error);
          reject(error);
        }
      });
    });
  };

function disconnect(socket) {
  socket.end(); 
}


function Originate(channel, exten = null, context = null, priority = null, application = null, data = null, timeout = null, callerid = null, variable = null, account = null, async = null, actionid = null) {
  let parameters = { Channel: channel };
  console.log("commming to originate function....    ");
  if (exten) parameters.Exten = exten;
  if (context) parameters.Context = context;
  if (priority) parameters.Priority = priority;

  if (application) parameters.Application = application;
  if (data) parameters.Data = data;

  if (timeout) parameters.Timeout = timeout;
  if (callerid) parameters.CallerID = callerid;
  if (variable) parameters.Variable = variable;
  if (account) parameters.Account = account;
  if (async !== null) parameters.Async = async ? 'true' : 'false';
  if (actionid) parameters.ActionID = actionid;
  // console.log('checking originate',parameters )
  return send_request('Originate', parameters,socket);
}



    
function send_request(action, parameters = {}, socket) {
 
  let req = `Action: ${action}\r\n`;

  for (let varName in parameters) {
    let value = parameters[varName];
    req += `${varName}: ${value}\r\n`;
  }
  req += '\r\n';  
  socket.write(req);
  if (action === 'Originate') {
    return waitResponseWithEvents(true, 2,socket);
  } else if (action === 'Command') {
    return waitResponseManager(true);
  } else if (action === 'Status') {
    if (Object.keys(parameters).length === 0) {
      return waitResponseWithEvents(true, 100);
    } else {
      return waitResponseWithEvents(true, 3);
    }
  } else {
    return waitResponse(true,socket);
  }
}


function waitResponse(allowTimeout = false, socket) {
  let timeout = false;

  return new Promise((resolve, reject) => {
    const processResponse = () => {
      let type = null;
      const parameters = {};

      let buffer = '';
      
      const onData = (data) => {
      
        buffer += data.toString();
        const lines = buffer.split('\r\n');
         
        for (let i = 0; i < lines.length - 1; i++) {
          const line = lines[i];
          if (line === '') continue;
           
          const index = line.indexOf(':');
          if (index !== -1) {
            const key = line.substring(0, index).trim();
            const value = line.substring(index + 1).trim();
            if (key === 'Event' || key === 'Response') {
              type = value.toLowerCase();
            } else if (value === 'Follows') {
              parameters.data = '';
              i++;
              while (lines[i] !== '--END') {
                parameters.data += lines[i] + '\n';
                i++;
              }
            } else {
              parameters[key] = value;
            }
          }
        }
        buffer = lines[lines.length - 1];
      };

      const onTimeout = () => {
        timeout = true;
        resolve(parameters);
      };

      socket.on('data', onData);
      if (allowTimeout) {
        setTimeout(onTimeout, 5000); 
      }
    };

    processResponse();

    const intervalId = setInterval(() => {
      if (timeout) {
        clearInterval(intervalId);
      } else {
        processResponse();
        // if (parameters.Event || parameters.Response) {
        //   clearInterval(intervalId);
        //   resolve(parameters);
        // }
      }
    }, 100);
  });
}

function waitResponseWithEvents(allowTimeout = false, requiredEventsWithResponse = 2, socket) {
  const master = {
    event: [],
    output: [],
    timeout: [],
    response: [],
    unhandled_response: [],
  };

  let eventCollected = 0;
  let responseCollected = false;
  let responseError = false;
  let endDetected = false;
  let whileRun = true;

  return new Promise((resolve) => {
    const onData = (data) => {
      const buffer = data.toString();
      const bufferLines = buffer.split('\r\n');
      // console.log("check the bufffer >>>>>>>>>>>", buffer)
      // console.log("check the bufffer >>>>>>>>>>>", bufferLines.length)

      for (let i = 0; i < bufferLines.length && whileRun; i++) {
        const line = bufferLines[i];
        let type = null;
        let parameters = {};

        const colonIndex = line.indexOf(':');
        if (colonIndex !== -1) {
          const key = line.substring(0, colonIndex).trim();
          const value = line.substring(colonIndex + 1).trim();

          if (key === 'Event') {
            type = 'event';
          }

          if (type === 'event') {
            parameters[key] = value;
          } else {
            if (parameters[key]) {
              parameters[key].push(value);
            } else {
              parameters[key] = [value];
            }
          }
        }

        if (type === 'event') {
          master.event.push(parameters);
          eventCollected++;
        } else if (type === 'response') {
          master.response.push(parameters);
          responseCollected = true;

          if (parameters['Response'] && parameters['Response'][0] === 'Error') {
            responseError = true;
          }

          if (parameters['Response'] && parameters['Response'][0] === 'Goodbye') {
            endDetected = true;
          }
        } else {
          master.unhandled_response.push(parameters);
        }

        if (responseError || endDetected) {
          whileRun = false;
        }

        if (master.event.some((event) => event['Event'] == 'Newexten')) {

          whileRun = false;
        }
        
        if (master.event.some((event) => event['Event'] == 'VarSet')) {

          whileRun = false;
        }

        if (master.event.some((event) => event['Event'] == 'Hangup')) {

          whileRun = false;
        }

        if (master.event.some((event) => event['Event'] == 'Newchannel')) {

          whileRun = false;
        }
        
        if (responseCollected && eventCollected === requiredEventsWithResponse && !allowTimeout) {
          whileRun = false;
        }
      }   
      if (whileRun) {
        console.log("its coming to that function ")
        const masterOutput = {
          Response: (master.unhandled_response[0] && master.unhandled_response[0]['Response']) ? master.unhandled_response[0]['Response'][0] : null,
          Message: (master.unhandled_response[1] && master.unhandled_response[1]['Message']) ? master.unhandled_response[0]['Message'] : null,
          Events: master.event,
          Outputs: master.unhandled_response[0] ? master.unhandled_response[0]['Output'] : null,
        };
         console.log("checking master output",master.event)

        if (responseError) {
          masterOutput.Response = 'Error';
        
        }

        resolve(masterOutput);

      }
    };

    const onError = (error) => {
      console.error('Socket error:', error);
      resolve(null);
    };

    const onClose = () => {
      console.log('Socket closed');
      resolve(null);
    };

    socket.on('data', onData);
    socket.on('error', onError);
    socket.on('close', onClose);
  });
}




// function waitResponseWithEvents(socket, allow_timeout = false, required_events_with_response = 2, outputs = null) {
//   let timeout = false;
//   let master = {
//     event: [],
//     output: []
//   };

//   let event_collected = 0;
//   let response_collected = false;
//   let response_error = false;
//   let end_detected = false;
  
//   function handleData(data) {
//     let type = null;
//     let parameters = {};


//     switch (type) {
//       case '':
//         timeout = allow_timeout;
//         master['timeout'] = [true];
//         break;
//       case 'event':
//         master['event'].push(parameters);
//         event_collected++;
//         break;
//       case 'response':
//         master['response'] = [parameters];
//         response_collected = true;
//         if (parameters['Response'][0] === 'Error') {
//           response_error = true;
//         }
//         if (parameters['Response'][0] === 'Goodbye') {
//           end_detected = true;
//         }
//         break;
//       default:
//         master['unhandled_response'] = parameters;
//         break;
//     }

//     if (outputs !== null) {
//       if (master.hasOwnProperty('response')) {
//         const count = master['response'][0]['Output'].length;
//         if (count > 0 && master['response'][0]['Output'][count - 1] === null) {
//           end_detected = true;
//         }
//       }
//     }

//     if (response_error || end_detected) {
//       while_run = false;
//     } else {
//       if (response_collected && event_collected === required_events_with_response && !timeout) {
//         while_run = false;
//       } else {
//         while_run = true;
//       }
//     }
//   }

//   // Perform any necessary socket initialization, connection, etc.

//   // Attach the appropriate event listener to the socket
//   socket.onData = handleData;

//   // Clean up the event listener when done
//   socket.onData = null;

//   const master_output = {
//     Response: (master['response'] && master['response'][0]['Response'][0]) || null,
//     Message: (master['response'] && master['response'][0]['Message'][0]) || null,
//     Events: master['event'] || null,
//     Outputs: (master['response'] && master['response'][0]['Output']) || null,
//   };

//   if (response_error) {
//     master_output['Response'] = 'Error';
//   }

//   return master_output;




// }






// function waitResponseWithEvents(allow_timeout  = false,  required_events_with_response = 2, outputs = null) {

//   console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
//   let timeout = false;
//   let master = { event: [], output: [] };
//   let event_collected = 0;
//   let response_collected = false;
//   let response_error = false;
//   let end_detected = false;

//   const rl = readline.createInterface({
//     input: process.stdin,
//     output: process.stdout
//   });
//   function readLine(rl) {
//     return new Promise((resolve) => {
//       rl.once('line', (line) => {
//         console.log("checking resolve------------------------", line);
//         resolve(line);
//       });
//     });
//   }
  
  
//   async function runWaitResponse() {
//     do {
     
//       let type = null;
//       let parameters = {};
//       let buffer = (await readLine(rl)).trim();
//       console.log("buffffffer",buffer)

//       while (buffer !== ''){
//         const a = buffer.indexOf(':');
//         if (a !== -1) {
//           if (Object.keys(parameters).length === 0) {
//             type = buffer.substring(0, a).toLowerCase();
//             if (buffer.substring(a + 2) === 'Follows') {
//               parameters.data = '';
//               let buff = (await readLine()).trim();
//               while (!buff.startsWith('--END ')) {
//                 parameters.data += buff;
//                 buff = (await readLine()).trim();
//               }
//             }
//           }

//           const key = buffer.substring(0, a);
//           const value = buffer.substring(a + 2);
//           if (type === 'event') {
//             parameters[key] = value;
//           } else {
//             parameters[key] = parameters[key] || [];
//             parameters[key].push(value);
//           }
//         }
//         buffer = (await readLine()).trim();
//       }
//       switch (type) {
//         case '':
//           timeout = allow_timeout;
//           master.timeout = master.timeout || [];
//           master.timeout.push(true);
//           break;
//         case 'event':
//           master.event.push(parameters);
//           event_collected++;
//           break;
//         case 'response':
//           master.response = master.response || [];
//           master.response.push(parameters);
//           response_collected = true;
//           if (parameters.Response[0] === 'Error') {
//             response_error = true;
//           }
//           if (parameters.Response[0] === 'Goodbye') {
//             end_detected = true;
//           }
//           break;
//         default:
//           master.unhandled_response = master.unhandled_response || [];
//           master.unhandled_response.push(parameters);
//           break;
//       }
//       if (outputs !== null) {
//         if (master.response) {
//           const count = master.response[0].Output.length;
//           if (count > 0 && master.response[0].Output[count - 1] === null) {
//             end_detected = true;
//           }
//         }
//       }

//       const response_error_detected = response_error || end_detected;
//       if (response_error_detected) {
//         break;
//       } else {
//         const response_collected_required = response_collected && event_collected === required_events_with_response && !timeout;
//         if (response_collected_required) {
//           break;
//         }
//       }
//     } while (true);

//     rl.close();
//     const master_output = {
//       Response: master.response && master.response.length > 0 && master.response[0].Response ? master.response[0].Response[0] : null,
//       Message: master.response && master.response.length > 0 && master.response[0].Message ? master.response[0].Message[0] : null,
//       Events: master.event || null,
//       Outputs: master.response ? master.response[0].Output : null,
//     };

//     if (master_output.Response !== 'Success') {
//     }
//     return master_output;
//     }
//  return runWaitResponse();
// }

module.exports = {
  Connect,
  Originate,
  waitResponseWithEvents,
  disconnect
}
  





















































































































    // const socket = new net.Socket();
    
    // socket.connect(port, server, () => {
    //   socket.once('data', (data) => {
    //     const str = data.toString();
    //     if (str === '') {
    //       // a problem.
    //       reject(new Error('Asterisk Manager header not received.'));
    //     } else {
    //       // login
    //       const request = {
    //         Action: 'login',
    //         Username: username,
    //         Secret: secret
    //       };
          
    //       sendRequest(socket, request)
    //         .then((response) => {
    //           if (response.Response !== 'Success') {
    //             reject(new Error(response.Message));
    //           } else {
    //             resolve({
    //               success: true,
    //               message: response.Message,
    //               data: socket
    //             });
    //           }
    //         })
    //         .catch((error) => reject(error));
    //     }
    //   });
    // });

    // socket.on('error', (error) => {
    //   reject(new Error(`Unable to connect to manager ${server}:${port}: ${error.message}`));
    // });
//   });
// }

// function sendRequest(socket, request) {
//   return new Promise((resolve, reject) => {
//     const requestStr = formatRequest(request);
//     socket.write(requestStr);
//     socket.once('data', (data) => {
//       const response = parseResponse(data.toString());
//       resolve(response);
//     });
//     socket.on('error', (error) => {
//       reject(new Error(`Error sending request: ${error.message}`));
//     });
//   });
// }



//  /////////action originate code////////////
//   if (action === "Originate") {
//     return waitResponseWithEvents(true, 3);
//   } else if (action === "Command") {
//     return waitResponseManager(true);
//   } else if (action === "Status") {
//     if (!parameters) {
//       return waitResponseWithEvents(true, 100);
//     } else {
//       return waitResponseWithEvents(true, 3);
//     }
//   } else {
//     return waitResponse();
//   }









// const net = require('net');

// function connect(server = null, username = null, secret = null, port = 5038) {

//   if (server === null) server = this.config.asmanager.server;
//   if (username === null) username = this.config.asmanager.username;

//   if (secret === null) secret = this.config.asmanager.secret;


//   if (server.includes(':')) {
//     const [host, portStr] = server.split(':');
//     this.server = host;
//     this.port = portStr;
//   } else {
//     this.server = server;
//     this.port = port; 
//   }


//   const socket = new net.Socket();
//   let log, connected;

//   socket.on('error', (err) => {
//     log = `Unable to connect to manager ${this.server}:${this.port} (${err.code}): ${err.message}`;
//     connected = false;
//   });

//   socket.connect(this.port, this.server, () => {
 
//     socket.once('data', (data) => {
//       const str = data.toString();

//       if (str === '') {
   
//         log = 'Asterisk Manager header not received.';
//         connected = false;
//       } else {
     
//         const res = this.send_request('login', { Username: username, Secret: secret });

//         if (res.Response !== 'Success') {
//           this._logged_in = false;
         
//           log = res.Message;
//           socket.destroy();
//           connected = false;
//         } else {
//           log = res.Message;
//           connected = true;
//           this._logged_in = true;
//         }
//       }

//       const response = {
//         success: connected,
//         message: log,
//         data: socket,
//       };

   
//     });
//   });
// }

// connect(Originate);

// ////////

// function Originate(channel, exten = null, context = null, priority = null, application = null, data = null, timeout = null, callerid = null, variable = null, account = null, async = null, actionid = null) {
//   const parameters = { Channel: channel };

//   if (exten) parameters.Exten = exten;
//   if (context) parameters.Context = context;
//   if (priority) parameters.Priority = priority;

//   if (application) parameters.Application = application;
//   if (data) parameters.Data = data;

//   if (timeout) parameters.Timeout = timeout;
//   if (callerid) parameters.CallerID = callerid;
//   if (variable) parameters.Variable = variable;
//   if (account) parameters.Account = account;
//   if (async !== null) parameters.Async = async ? 'true' : 'false';
//   if (actionid) parameters.ActionID = actionid;

//   return sendRequest('Originate', parameters);
// }



// amiController.initialSipCall = (req, res) => {
//     var ami = new require('asterisk-manager')('5038', '192.168.0.248', 'mayur', 'mayur', true);
//     ami.keepConnected();
  
//     ami.on('managerevent', function (evt) { });
//     ami.on('hangup', function (evt) { });
//     ami.on('confbridgejoin', function (evt) { });
//     ami.on('response', function (evt) { });
  
//     ami.action({
//       'action': 'originate',
//       'channel': 'SIP/1001',
//       'context': 'csr',
//       'exten': 1003,
//       'priority': 1,
//       'variable': {
//         // 'name1': 'value1',
//         // 'name2': 'value2'
//       }
//     }, function (err, result) {
//       if (err) {
//         console.error(err);
//         res.status(500).send('An error occurred');
//       } else {
//         console.log(result);
//         res.status(200).send(result);
//       }
//     });
//   };
// module.exports = Asterisk;