module.exports = {
    validate: {
      isEmpty: 'This field is required!',
      isLength50: 'This field length should be between 2 to 50!',
      isLength300: 'This field length should be between 2 to 300!',
      isLength: 'This field length should be minimum 2!',
      isMongoID: 'This field is invalid',
    },
    errorIn: {
      inputErrors: 'Invalid Inputs'
    },
    usersettingSave: 'userdailersetting saved successful!',
    usersettingGet: 'userdailersetting get successful!',
    namesGet: 'userdailersetting Names get successful!',
    usersettingDelete: 'userdailersetting deleted successfully!',
    usersettingNotFound: 'userdailersetting Not Found',
    settingNotFound:"userdailersetting not found ",
    settingUpdate:"userdailersetting updated successfully",
  };