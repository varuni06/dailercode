const mongoose = require('mongoose');
const schema = mongoose.Schema;

const userdailersettingSchema = new schema({
  id: { type: String },
  extention: { type: String},
  user_extension_number: { type: Number},
  did:{type:String},
  extention_password: { type: Number },
  asterisk_server_ip: { type: Number },
  user_id: { type: Number },
  conference_no: { type: Number },
  group_no: { type: String},
  status: { type: String },
  active_list_id: { type: Number },
  active_campaign_id: { type: Number },
  active_call_id: { type: Number},
  permissions: { type: String },
  time_permission: { type: Number },
  dialer_logged_in: { type: Number },
  current_queue: { type: String},
  sip_connected_ip: { type: Number },
  sip_phone: { type: Number},
  agent_conferance_channel_id: { type: String },
  created_at: { type: Date },
  updated_at: { type: Date },
  deleted_at: { type: Date },
  is_active: { type: Boolean, required: true, default: true },
});

module.exports = userdailersettingSch = mongoose.model('userdailersettings', userdailersettingSchema);



// module.exports = usersdailersettings = mongoose.model('usersdailersettings', userdailersettingSchema);
//module.exports = mongoose.model('userdailersettings', userdailersettingSchema) || mongoose.model('userdailersettings', userdailersettingSchema);
// module.exports = mongoose.model.userdailersettings || new mongoose.model('userdailersettings', userdailersettingSchema);






