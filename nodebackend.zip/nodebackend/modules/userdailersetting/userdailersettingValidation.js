const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const userdailersettingConfig = require('./userdailersettingConfig');
const userdailersettingSch = require('./userdailersettingSchema');
const userdailersettingValidation = {};

userdailersettingValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
    {
      field: 'agent_id',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'extention',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'extention_password',
      sanitize: {
        trim: true,
      },
    },
    {
        field: 'asterisk_server_ip',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'user_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'conference_no',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'group_no',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'status',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'active_list_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'active_campaign_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'active_call_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'permissions',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'time_permission',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'dialer_logged_in',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'current_queue',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'sip_connected_ip',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'sip_phone',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'agent_conferance_channel_id',
        sanitize: {
          trim: true,
        },
      },
  ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

userdailersettingValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: userdailersettingConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'agent_id',
      validate: [
        {
          condition: 'IsEmpty',
          msg: userdailersettingConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'extention',
      validate: [
        {
          condition: 'IsEmpty',
          msg: userdailersettingConfig.validate.isEmpty,
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    {
      field: 'extention_password',
      validate: [
        {
          condition: 'IsEmpty',
          msg: userdailersettingConfig.validate.isEmpty,
        },
      ],
    },

    {
        field: 'asterisk_server_ip',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'user_id',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
          {
            condition: 'NotFound',
            msg: 'User ID not found.',
          },
          {
            condition: 'AlreadyExists',
            msg: 'User ID already exists.',
          }
        ],
      },
      {
        field: 'conference_no',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
        ],
      },

      {
        field: 'group_no',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
        ],
      },

      {
        field: 'status',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
          
        ],
      },


      {
        field: 'active_list_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'active_campaign_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'active_call_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },

        ],
      },

      {
        field: 'permissions',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
        ],
      },

      {
        field: 'time_permission',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
        ],
      },

      {
        field: 'dialer_logged_in',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'current_queue',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'sip_connected_ip',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'sip_phone',
        validate: [
          {
            condition: 'IsEmpty',
            msg: userdailersettingConfig.validate.isEmpty,
          },
        ],
      },

      {
        field: 'agent_conferance_channel_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: userdailersettingConfig.validate.isEmpty,
          // },
        ],
      },
    
  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, user_id: data.user_id}
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await userdailersettingSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, theme_key: ' User dialer already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, userdailersettingConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = userdailersettingValidation
;
