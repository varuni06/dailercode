const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const userdailersettingConfig = require('./userdailersettingConfig');
const userdailersettingSch = require('./userdailersettingSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const userdailersettingController = {};

userdailersettingController.getusersetting = async (req, res, next) => {
    try {
      let { page, size, populate, selectQuery, searchQuery, sortQuery } = otherHelper.parseFilters(req, 10, false);
      selectQuery = 'id  extention  extention_password   asterisk_server_ip   user_id   conference_no   group_no  status  active_list_id  active_campaign_id   active_call_id  permissions   time_permission   dialer_logged_in   current_queue   sip_connected_ip  sip_phone   agent_conferance_channel_id ';
        const names = await userdailersettingSch.find().select('id  extention  extention_password   asterisk_server_ip   user_id   conference_no   group_no  status  active_list_id  active_campaign_id   active_call_id  permissions   time_permission   dialer_logged_in   current_queue   sip_connected_ip  sip_phone   agent_conferance_channel_id ');
        return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, userdailersettingConfig.namesGet, null);
    } catch (err) {
        next(err);
    }
};


userdailersettingController.getusersettingDetail = async (req, res, next) => {
    console.log(req.query.id)
    const menu = await userdailersettingSch.findById(req.query.id, { active_call_id:1, extention:1,  extention_password :1 , asterisk_server_ip:1,   user_id:1,  conference_no:1,group_no:1, status:1, active_list_id:1,  permissions:1 ,  time_permission:1, dialer_logged_in:1, current_queue:1 ,  sip_connected_ip :1   , sip_phone:1   , agent_conferance_channel_id:1 });
    console.log(menu);
    return otherHelper.sendResponse(res, httpStatus.OK, true, menu, null, userdailersettingConfig.namesGet, null, 'Role Not Found');
  };


userdailersettingController.postusersetting = async (req, res, next) => {
    try {
        const theme = req.body;
        theme.updated_by = req.user.id;
        theme.updated_at = Date.now();
        if (theme && theme.id) {
            const update = await userdailersettingSch.findByIdAndUpdate({ _id: theme.id }, { $set: theme }, { new: true });
            return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, userdailersettingConfig.usersettingSave, null);
        } else {
            let newTheme = new userdailersettingSch(theme);
            let saved = await newTheme.save();
            return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, userdailersettingConfig.usersettingSave, null);
        }
    } catch (err) {
        next(err);
    }
};

userdailersettingController.Deleteusersetting = async (req, res, next) => {
    try {
      const id = req.query.id;
      console.log(id)
      const listcall = await userdailersettingSch.findByIdAndRemove(id, {
        $set: {
          is_deleted: true,
          deleted_at: new Date(),
        },
      });
      return otherHelper.sendResponse(res, httpStatus.OK, true, listcall, null, userdailersettingConfig.usersettingDelete, null);
    } catch (err) {
      next(err);
    }
    
  };

  userdailersettingController.Searchusersetting = async (req, res, next) => {
    const usersetting = await userdailersettingSch.find({
      $or: [{ extention : { $regex: req.query.key } }],
    });
    return otherHelper.sendResponse(res, httpStatus.OK, true, usersetting, null,  userdailersettingConfig.namesGet, null, 'Agent Not Found');
  };

  
module.exports = userdailersettingController;
