
const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const cdrConfig = require('./cdrConfig');
const cdrSch = require('./cdrSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const cdrController = {};


cdrController.getcdr = async (req, res, next) => {
  try {
    const names = await cdrSch.find().select('id  field  src  dst  dcontext clid channel dstchannel lastapp lastdate start end  duration  billsec  disposition amaflags Uniqueid');
    return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, cdrConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};


cdrController.getcdrDetail = async (req, res, next) => {
  console.log(req.query.id)
  const roles = await cdrSch.findById(req.query.id, { id: 1, field: 1, src: 1 , dst:1,dcontext:1, clid:1,channel:1, dstchannel:1, lastapp :1, lastdate:1,start:1, end:1, duration:1, billsec:1, disposition:1,amaflags:1, Uniqueid:1});
  console.log(roles)
  return otherHelper.sendResponse(res, httpStatus.OK, true, roles, null, cdrConfig.namesGet, null, 'cdr Not Found');
};

cdrController.searchcdr = async (req, res, next) => {
  const users = await cdrSch.find({
    $or: [{ field : { $regex: req.query.key } }],
  });
  return otherHelper.sendResponse(res, httpStatus.OK, true, users, null,  cdrConfig.namesGet, null, 'CDR Not Found');
};


module.exports = cdrController
