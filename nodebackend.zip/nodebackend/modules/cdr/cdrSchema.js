const mongoose = require('mongoose');
const schema = mongoose.Schema;

const cdrSchema = new schema({
  id: { type: Number },
  field: { type: String },
  src: { type: String },
  dst : { type: String },
  dcontext:{type:String},
  clid:{type:String},
  channel:{type:String},
  dstchannel:{type:String},
  lastapp:{type:String},
  lastdate:{type:String},
  start:{type:Date},
  end:{type: Date},
  duration:{type: Number},
  billsec : {type:Number},
  disposition:{type:String},
  amaflags:{type:String},
  Uniqueid:{type:Number},
  created_by: { type: Date },
  updated_at:{type:Number},
  account_code:{type:String}
});

module.exports = cdr = mongoose.model('cdr', cdrSchema);                                                                                                         

// module.exports = mongoose.model.cdrSchema || new mongoose.model('cdrs', cdrSchema);

// module.exports = mongoose.model('cdr',cdrSchema ) || mongoose.model('cdr', cdrSchema);