const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const cdrConfig = require('./cdrConfig');
const cdrSch = require('./cdrSchema');
const cdrValidation = {};

cdrValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
    {
      field: 'id',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'field',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'src',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'dcontext',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'clid',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'channel',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'dstchannel',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'lastapp',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'lastdate',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'start',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'end',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'duration',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'billsec',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'disposition',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'amaflags',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'Uniqueid',
      sanitize: {
        trim: true,
      },
    },
     {
      field: 'dst',
      sanitize: {
        trim: true,
      },
    },
   ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

cdrValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: cdrConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'id',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'dcontext',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'clid',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'channel',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'dstchannel',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'lastapp',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'lastdate',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'start',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'end',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'duration',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'billsec',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'disposition',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'amaflags',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
      {
      field: 'Uniqueid',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },


    {
      field: 'field',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    {
      field: 'src',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
       
      ],
    },
    {
      field: 'dst',
      validate: [
        {
          condition: 'IsEmpty',
          msg: cdrConfig.validate.isEmpty,
        },
      ],
    },
];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, field: data.field }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await cdrSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, theme_key: 'dsetting already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, themeConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = cdrValidation;
