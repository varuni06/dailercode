const mongoose = require('mongoose');
const schema = mongoose.Schema;

const themeSchema = new schema({
  theme_name: { type: String },
  theme_key: { type: String},
  information: { type: String },
  variables: [{ type: String }],
  from: { type: String },
  subject: { type: String},
  alternate_text: { type: String},
  body: { type: String},
  updated_at: { type: Date },
  updated_by: { type: schema.Types.ObjectId, ref: 'users' },
  is_deleted: { type: Boolean, default: false, required: true },
  deleted_by: { type: schema.Types.ObjectId, ref: 'users' },
  deleted_at: { type: Date },
});

module.exports = theme = mongoose.model('theme', themeSchema);
