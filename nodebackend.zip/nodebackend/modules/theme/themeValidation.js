const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const themeConfig = require('./themeConfig');
const themeSch = require('./themeSchema');
const themeValidation = {};

themeValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
    {
      field: 'theme_name',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'theme_key',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'information',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'variables',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'from',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'subject',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'body',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'alternative_text',
      sanitize: {
        trim: true,
      },
    },
  ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

themeValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: themeConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'theme_name',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
      ],
    },
    {
      field: 'theme_key',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    {
      field: 'information',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength300,
          option: { min: 2, max: 300 },
        },
      ],
    },
    {
      field: 'variables',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'from',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
      ],
    },
    {
      field: 'subject',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength,
          option: { min: 2, max: 300 },
        },
      ],
    },
    {
      field: 'body',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength,
          option: { min: 2 },
        },
      ],
    },
    {
      field: 'alternate_text',
      validate: [
        {
          condition: 'IsEmpty',
          msg: themeConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: themeConfig.validate.isLength,
          option: { min: 2 },
        },
      ],
    },
  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, theme_key: data.theme_key }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await themeSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, theme_key: 'theme_key already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, themeConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = themeValidation;
