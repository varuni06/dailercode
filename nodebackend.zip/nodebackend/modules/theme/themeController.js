const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const themeConfig = require('./themeConfig');
const themeSch = require('./themeSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const themeController = {};


themeController.getThemeName = async (req, res, next) => {
  try {
    const names = await themeSch.find().select('theme_name theme_key');
    return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, themeConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};

themeController.postTheme = async (req, res, next) => {
  try {
    const theme = req.body;
    theme.updated_by = req.user.id;
    theme.updated_at = Date.now();
    if (theme && theme._id) {
      const update = await themeSch.findByIdAndUpdate({ _id: theme._id }, { $set: theme }, { new: true });
      return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, themeConfig.themeSave, null);
    } else {
      let newTheme = new themeSch(theme);
      let saved = await newTheme.save();
      return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, themeConfig.themeSave, null);
    }
  } catch (err) {
    next(err);
  }
};

themeController.DeleteTheme = async (req, res, next) => {
  try {
    const id = req.query.id;
    console.log(id)
    const theme = await themeSch.findByIdAndUpdate(id, {
      $set: {
        is_deleted: true,
        deleted_at: new Date(),
      },
    });
    return otherHelper.sendResponse(res, httpStatus.OK, true, theme, null, themeConfig.themeDelete, null);
  } catch (err) {
    next(err);
  }
  
};

module.exports = themeController
