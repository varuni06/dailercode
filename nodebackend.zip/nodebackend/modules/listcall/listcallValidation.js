const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const listcallConfig = require('./listcallConfig');
const listcallSch = require('./listcallSchema');
const listcallValidation = {};

listcallValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
   {
      field: 'listcall_title',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'conference_no',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'group_no',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'lead_id',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'mobile',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'listnode',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'status',
      sanitize: {
        trim: true,
      },
    },
    {
        field: 'liststatus',
        sanitize: {
          trim: true,
        },
    },
    {
        field: 'list_UID_number',
        sanitize: {
          trim: true,
        },
    },

    {
        field: 'houpor_call_id',
        sanitize: {
          trim: true,
        },
    },

    {
        field: 'campaign_id',
        sanitize: {
          trim: true,
        },
    },
    {
        field: 'list_lead_id',
        sanitize: {
          trim: true,
        },
    },
      {
        field: 'disposition_status',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'crm_campaign_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'crm_customer_id',
        sanitize: {
          trim: true,
        },
      },
      {
        field: 'crm_lead_id',
        sanitize: {
          trim: true,
        },
      },
    ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

listcallValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: listcallConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'listcall_id',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
        
      ],
    },
    {
      field: 'listcall_title',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    {
      field: 'conference_no',
      validate: [
        // {
        //   condition: 'IsEmpty',
        //   msg: listcallConfig.validate.isEmpty,
        // },
    
      ],
    },
    {
      field: 'group_no',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'lead_id',
      validate: [
        // {
        //   condition: 'IsEmpty',
        //   msg: listcallConfig.validate.isEmpty,
        // },
      
      ],
    },
    {
      field: 'mobile',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'listnode',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
        // {
        //   condition: 'IsLength',
        //   msg: listcallConfig.validate.isLength,
        //   option: { min: 2 },
        // },
      ],
    },
    {
      field: 'status',
      validate: [
        {
          condition: 'IsEmpty',
          msg: listcallConfig.validate.isEmpty,
        },
        // {
        //   condition: 'IsLength',
        //   msg: listcallConfig.validate.isLength,
        //   option: { min: 2 },
        // },
      ],
    },


    {
        field: 'liststatus',
        validate: [
          {
            condition: 'IsEmpty',
            msg: listcallConfig.validate.isEmpty,
          },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },


      {
        field: 'list_UID_number',
        validate: [
          {
            condition: 'IsEmpty',
            msg: listcallConfig.validate.isEmpty,
          },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },


      {
        field: 'houpor_call_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: listcallConfig.validate.isEmpty,
          // },
        ],
      },

      {
        field: 'campaign_id',
        validate: [
          {
            condition: 'IsEmpty',
            msg: listcallConfig.validate.isEmpty,
          },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },


      {
        field: 'list_lead_id',
        validate: [
          {
            condition: 'IsEmpty',
            msg: listcallConfig.validate.isEmpty,
          },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },

      {
        field: 'disposition_status',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: listcallConfig.validate.isEmpty,
          // },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },

      {
        field: 'crm_campaign_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: listcallConfig.validate.isEmpty,
          // },
          
        ],
      },

      {
        field: 'crm_customer_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: listcallConfig.validate.isEmpty,
          // },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },

      {
        field: 'crm_lead_id',
        validate: [
          // {
          //   condition: 'IsEmpty',
          //   msg: listcallConfig.validate.isEmpty,
          // },
          // {
          //   condition: 'IsLength',
          //   msg: listcallConfig.validate.isLength,
          //   option: { min: 2 },
          // },
        ],
      },
  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, listcall_id: data.listcall_id }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await listcallSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, listcall_id: 'listcall already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, listcallConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = listcallValidation;
