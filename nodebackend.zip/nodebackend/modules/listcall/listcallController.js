const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const listcallConfig = require('./listcallConfig');
const listcallSch = require('./listcallSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const listcallController = {};


listcallController.getListcallName = async (req, res, next) => {
  try {

    if (req.query.id) {
      const Listcall = await listcallSch.find({
        $or: [{ lead_id: req.query.id }],
      });
      return otherHelper.sendResponse(res, httpStatus.OK, true, Listcall, null, listcallConfig.namesGet, null, 'Listcall Not Found');
    }

    const names = await listcallSch.find().select( '_id listcall_id conference_no group_no lead_id  mobile listnode status liststatus list_UID_number  houpor_call_id  campaign_id disposition_status  created_at updated_at');
    return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, listcallConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};

listcallController.getListcallNamedetail = async (req, res, next) => {
  console.log(req.query.id)
  const menu = await listcallSch.findById(req.query.id, {_id:1,  listcall_id :1, listcall_title:1 ,conference_no:1,list_lead_id:1, group_no :1, lead_id:1,  mobile:1, listnode :1, status : 1, liststatus:1, list_UID_number :1, houpor_call_id :1, campaign_id :1, disposition_status :1, created_at :1, updated_at:1 });
  console.log(menu);
  return otherHelper.sendResponse(res, httpStatus.OK, true, menu, null,listcallConfig.namesGet, null, 'Dsetting Not Found');
};

listcallController.postlistcall = async (req, res, next) => {
  try {
    const listcall = req.body;
    listcall.updated_by = req.user.id;
    listcall.updated_at = Date.now();
    if (listcall && listcall.id) {
      console.log(listcall)
      const update = await listcallSch.findByIdAndUpdate({ _id: listcall.id }, { $set: listcall }, { new: true });
      console.log(update)
      return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, listcallConfig.listcallSave, null);
    } else {

      let newlistcall = new listcallSch(listcall);
      console.log(listcall)
      console.log(newlistcall)
      let saved = await newlistcall.save();
      return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, listcallConfig.listcallSave, null);
    }
  } catch (err) {
    next(err);
  }
};

listcallController.Deletelistcall = async (req, res, next) => {
  try {
    const id = req.query.id;
    const listcall = await listcallSch.findByIdAndRemove(id, {
      $set: {
        is_deleted: true,
        deleted_at: new Date(),
      },
    });
    return otherHelper.sendResponse(res, httpStatus.OK, true, listcall, null, listcallConfig.listcallDelete, null);
  } catch (err) {
    next(err);
  }
  
};

listcallController.GetSearchlistcall = async (req, res, next) => {
  const listcall = await listcallSch.find({
    $or: [{ listnode: { $regex: req.query.key } }],
  });
  return otherHelper.sendResponse(res, httpStatus.OK, true, listcall, null, listcallConfig.listcallGet, null, 'List Call Not Found');
  
};


module.exports = listcallController
