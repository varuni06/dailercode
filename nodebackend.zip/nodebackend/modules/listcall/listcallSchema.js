const mongoose = require('mongoose');
const schema = mongoose.Schema;

const listcallSchema = new schema({
  listcall_id: { type: Number },                   
  listcall_title: { type: String },                 
  conference_no: { type: Number },                  
  group_no: { type: Number },                       
  lead_id: { type: String },
  mobile: { type: Number },                          
  listnode: { type: String },                         
  status: { type: String },                            
  liststatus: { type: String },                        
  list_UID_number: { type: Number },                    
  houpor_call_id: { type: Number },                      
  campaign_id: { type: Number },                          
  created_at: { type: schema.Types.ObjectId, ref: 'users' },   
  // updated_at: { type: Date },                               
  list_lead_id: { type: Number },                            
  disposition_status: { type: String },                       
  crm_campaign_id: { type: Number },                           
  crm_customer_id: { type: Number },                            
  crm_lead_id: { type: Number },                                  
});



module.exports = listcall = mongoose.model('listcalls', listcallSchema);