const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const leadConfig = require('./leadConfig');
const leadSch = require('./leadSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const leadController = {};


leadController.getLeadName = async (req, res, next) => {
  try {
    const names = await leadSch.find().select( '_id name title lead_title lead_status is_active  updated_by updated_at');
    return otherHelper.sendResponse(res, httpStatus.OK, true, names, null, leadConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};



leadController.getLeadNamedetail = async (req, res, next) => {
 
  const menu = await leadSch.findById(req.query.id, { _id:1, name:1, title:1, lead_title:1, lead_status:1, is_active :1, updated_by:1, updated_at:1 });
  console.log(menu);
  return otherHelper.sendResponse(res, httpStatus.OK, true, menu, null,leadConfig.namesGet, null, 'Dsetting Not Found');
};


leadController.postlead = async (req, res, next) => {
  try {
    const lead = req.body;
    lead.updated_by = req.user.id;
    lead.updated_at = Date.now();
    if (lead && lead.id) {

      const update = await leadSch.findByIdAndUpdate({ _id: lead.id }, { $set: lead }, { new: true });
      return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, leadConfig.leadSave, null);
    } else {

      let newlead = new leadSch(lead);
      let saved = await newlead.save();
      return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, leadConfig.leadSave, null);
    }
  } catch (err) {
    next(err);
  }
};

leadController.Deletelead = async (req, res, next) => {
  try {
    const id = req.query.id;
    const lead = await leadSch.findByIdAndRemove(id, {
      $set: {
        is_deleted: true,
        deleted_at: new Date(),
      },
    });
    return otherHelper.sendResponse(res, httpStatus.OK, true, lead, null, leadConfig.leadDelete, null);
  } catch (err) {
    next(err);
  }
  
};

leadController.GetleadSearch = async (req, res, next) => {
  const leads = await leadSch.find({
    $or: [{ lead_title: { $regex: req.query.key } }],
  });
  return otherHelper.sendResponse(res, httpStatus.OK, true, leads, null, leadConfig.leadGet, null, 'Module Not Found');
};

module.exports = leadController
