const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const leadConfig = require('./leadConfig');
const leadSch = require('./leadSchema');
const leadValidation = {};

leadValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
    {
      field: 'lead_id',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'lead_title',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'lead_status',
      sanitize: {
        trim: true,
      },
    },
    
  ];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

leadValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: leadConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'lead_title',
      validate: [
        {
          condition: 'IsEmpty',
          msg: leadConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: leadConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
      ],
    },
    {
      field: 'lead_status',
      validate: [
        {
          condition: 'IsEmpty',
          msg: leadConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: leadConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
        {
          condition: 'IsProperKey',
          msg: 'not Valid Input',
        },
      ],
    },
    // {
    //   field: 'information',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //     {
    //       condition: 'IsLength',
    //       msg: leadConfig.validate.isLength300,
    //       option: { min: 2, max: 300 },
    //     },
    //   ],
    // },
    // {
    //   field: 'variables',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //   ],
    // },
    // {
    //   field: 'from',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //     {
    //       condition: 'IsLength',
    //       msg: leadConfig.validate.isLength50,
    //       option: { min: 2, max: 50 },
    //     },
    //   ],
    // },
    // {
    //   field: 'subject',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //     {
    //       condition: 'IsLength',
    //       msg: leadConfig.validate.isLength,
    //       option: { min: 2, max: 300 },
    //     },
    //   ],
    // },
    // {
    //   field: 'body',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //     {
    //       condition: 'IsLength',
    //       msg: leadConfig.validate.isLength,
    //       option: { min: 2 },
    //     },
    //   ],
    // },
    // {
    //   field: 'alternate_text',
    //   validate: [
    //     {
    //       condition: 'IsEmpty',
    //       msg: leadConfig.validate.isEmpty,
    //     },
    //     {
    //       condition: 'IsLength',
    //       msg: leadConfig.validate.isLength,
    //       option: { min: 2 },
    //     },
    //   ],
    // },
  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, lead_key: data.lead_key }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  // const already_key = await leadSch.findOne(key_filter);
  // if (already_key && already_key._id) {
  //   errors = { ...errors, them_key: 'lead_key already exist' }
  // }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, leadConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = leadValidation;
