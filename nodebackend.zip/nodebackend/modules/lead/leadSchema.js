const mongoose = require('mongoose');
const schema = mongoose.Schema;

const leadSchema = new schema({
  lead_id: { type: String },
  lead_title: { type: String },
  lead_status: { type: String},
  updated_at: { type: Date },
  created_at: { type: schema.Types.ObjectId, ref: 'users' },
  deleted_at: { type: Date },
  is_deleted: {type:Boolean},
});

module.exports = lead = mongoose.model('lead', leadSchema);
