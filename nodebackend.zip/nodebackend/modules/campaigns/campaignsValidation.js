const httpStatus = require('http-status');
const isEmpty = require('../../validation/isEmpty');
const otherHelper = require('../../helper/others.helper');
const sanitizeHelper = require('../../helper/sanitize.helper');
const validateHelper = require('../../helper/validate.helper');
const campaignsConfig = require('./campaignsConfig');
const campaignsSch = require('./campaignsSchema');
const campaignsValidation = {};

campaignsValidation.sanitized = (req, res, next) => {
  const sanitizeArray = [
    // {
    //   field: 'id',
    //   sanitize: {
    //     trim: true,
    //   },
    // },
    {
      field: 'title',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'ratio',
      sanitize: {
        trim: true,
      },
    },
    // {
    //   field: 'list_id',
    //   sanitize: {
    //     trim: true,
    //   },
    // },
    {
      field: 'dial_agent_disposition_status',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'main_queue',
      sanitize: {
        trim: true,
      },
    },
    {
      field: 'status',
      sanitize: {
        trim: true,
      },
    },
];
  sanitizeHelper.sanitize(req, sanitizeArray);
  next();
};

campaignsValidation.validate = async (req, res, next) => {
  const data = req.body
  const validateArray = [
    {
      field: '_id',
      validate: [
        {
          condition: 'IsMongoId',
          msg: campaignsConfig.validate.isMongoID,
        },
      ],
    },
    {
      field: 'title',
      validate: [
        {
          condition: 'IsEmpty',
          msg: campaignsConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: campaignsConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
      ],
    },
    {
      field: 'ratio',
      validate: [
        {
          condition: 'IsEmpty',
          msg: campaignsConfig.validate.isEmpty,
        },
      ],
    },
    // {
    //   field: 'list_id',
    //   validate: [
    //     // {
    //     //   condition: 'IsEmpty',
    //     //   msg: campaignsConfig.validate.isEmpty,
    //     // },
    //   ],
    // },
    {
      field: 'dial_agent_disposition_status',
      validate: [
        {
          condition: 'IsEmpty',
          msg: campaignsConfig.validate.isEmpty,
        },
      ],
    },
    {
      field: 'main_queue',
      validate: [
        {
          condition: 'IsEmpty',
          msg: campaignsConfig.validate.isEmpty,
        },
        {
          condition: 'IsLength',
          msg: campaignsConfig.validate.isLength50,
          option: { min: 2, max: 50 },
        },
      ],
    },
    {
      field: 'status',
      validate: [
        // {
        //   condition: 'IsEmpty',
        //   msg: campaignsConfig.validate.isEmpty,
        // },
        
      ],
    },

  ];
  let errors = validateHelper.validation(req.body, validateArray);

  let key_filter = { is_deleted: false, title: data.title }
  if (data._id) {
    key_filter = { ...key_filter, _id: { $ne: data._id } }
  }
  const already_key = await campaignsSch.findOne(key_filter);
  if (already_key && already_key._id) {
    errors = { ...errors, list_id: 'campaigns already exist' }
  }


  if (!isEmpty(errors)) {
    return otherHelper.sendResponse(res, httpStatus.BAD_REQUEST, false, null, errors, campaignsConfig.errorIn.inputErrors, null);
  } else {
    next();
  }
};

module.exports = campaignsValidation;
