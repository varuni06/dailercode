const mongoose = require('mongoose');
const schema = mongoose.Schema;

const campaignsSchema = new schema({
  // id: { type: Number },
  title: { type: String},
  ratio: { type: Number },
  list_id: { type: Number },
  dial_agent_disposition_status: { type: String },
  main_queue: { type: String},
  status: { type: String},
  updated_at: { type: Date },
  created_at: { type: Date },
  deleted_at: { type: Date },
});

module.exports = campaigns = mongoose.model('campaigns', campaignsSchema);


