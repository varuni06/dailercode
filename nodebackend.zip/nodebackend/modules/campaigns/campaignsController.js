const httpStatus = require('http-status');
const otherHelper = require('../../helper/others.helper');
const campaignsConfig = require('./campaignsConfig');
const campaignsSch = require('./campaignsSchema');
const leadSch = require('../lead/leadSchema');
const isEmpty = require('../../validation/isEmpty');
const { getSetting } = require('../../helper/settings.helper');
const lead = require("../lead/leadSchema");
const campaignsController = {};


campaignsController.getcampaigns = async (req, res, next) => {
  try {
    // const leadvalue = await lead.findOne({ lead_id });
    const data = await leadSch.aggregate([
      {
        $lookup: {
          from: 'leads',
          localField: 'lead_name',
          foreignField: 'lead_title',
          as: 'lead_name',
        },
      },
    ]);

    const names = await campaignsSch.find().select('main_queue title status ratio dial_agent_disposition_status');
    return otherHelper.sendResponse(res, httpStatus.OK, true, {names: names, data : data }, null, campaignsConfig.namesGet, null);
  } catch (err) {
    next(err);
  }
};


campaignsController.getcampaignsdetail = async (req, res, next) => {
 
  console.log(req.query.id)
  const menu = await campaignsSch.findById(req.query.id, {campaign_id:1,title:1,main_queue:1 ,status:1, ratio :1,dial_agent_disposition_status:1 });
  console.log(menu);
  return otherHelper.sendResponse(res, httpStatus.OK, true, menu, null, campaignsConfig.namesGet, null, 'campaigns Not Found');
};



// campaignsController.postcampaigns = async (req, res, next) => {
//   try {
//     const campaigns = req.body;
//     campaigns.updated_by = req.user.id;
//     campaigns.updated_at = Date.now();
//     if (campaigns && campaigns._id) {
//       const update = await campaignsSch.findByIdAndUpdate({ _id: campaigns._id }, { $set: campaigns }, { new: true });
//       // console.log(update)
//       return otherHelper.sendResponse(res, httpStatus.OK, true, update, null, campaignsConfig.campaignsSave, null);
//     } else {
//       let newTheme = new campaignsSch(theme);
//       // console.log(newTheme)
//       let saved = await newTheme.save();
//       return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, campaignsConfig.campaignsSave, null);
//     }
//   } catch (err) {
//     next(err);
//   }
// };



campaignsController.postcampaigns = async (req, res, next) => {
  try {
    const theme = req.body;
    theme.updated_by = req.user.id;
    theme.updated_at = Date.now();
    if (theme && theme.id) {
      const update = await campaignsSch.findByIdAndUpdate({ _id: theme.id }, { $set: theme }, { new: true });
      return otherHelper.sendResponse(res, httpStatus.OK, true, update, null,campaignsConfig.campaignsSave, null);
    } else {
      let newTheme = new campaignsSch(theme);
      let saved = await newTheme.save();
      return otherHelper.sendResponse(res, httpStatus.OK, true, saved, null, campaignsConfig.campaignsSave, null);
    }
  } catch (err) {
    next(err);
  }
};

campaignsController.Deletecampaigns = async (req, res, next) => {
  try {
    const id = req.query.id;
    
    const theme = await campaignsSch.findByIdAndRemove(id, {
      $set: {
        is_deleted: true,
        deleted_at: new Date(),
      },
    });
    return otherHelper.sendResponse(res, httpStatus.OK, true, theme, null, campaignsConfig.campaignsDelete, null);
  } catch (err) {
    next(err);
  }
  
};

campaignsController.Getcampaignsearch = async (req, res, next) => {
  const capaigns = await campaignsSch.find({
    $or: [{ title : { $regex: req.query.key } }],
  });
  return otherHelper.sendResponse(res, httpStatus.OK, true, capaigns, null, campaignsConfig.campaignsGet, null, 'campaign Not Found');
};


module.exports = campaignsController
