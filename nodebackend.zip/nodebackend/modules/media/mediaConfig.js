module.exports = {
  ValidationMessage: {
    GetMedia: 'Media Get Success !',
    SaveMedia: 'Media Saved Success !',
    DeleteMedia: 'Media Delete Success !',
  },
};
