module.exports = {
    secretOrKey: 'secret'
};