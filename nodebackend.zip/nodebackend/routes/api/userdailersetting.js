const express = require('express');
const router = express.Router();

const userdailersettingModule = require('../../modules/userdailersetting/userdailersettingController');
const userdailersettingValidation = require('../../modules/userdailersetting/userdailersettingValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

// router.get('/getusersetting', authentication, userdailersettingModule.getusersetting);

router.get('/getusersetting', authentication, userdailersettingModule.getusersetting);
router.get('/getusersettingid', authentication, userdailersettingModule.getusersettingDetail);
router.post('/addusersetting', authentication,userdailersettingValidation.sanitized, userdailersettingValidation.validate,  userdailersettingModule.postusersetting);
router.get('/delusersetting', authentication, userdailersettingModule.Deleteusersetting);
router.get('/search-usersetting', authentication, userdailersettingModule.Searchusersetting);

module.exports = router;