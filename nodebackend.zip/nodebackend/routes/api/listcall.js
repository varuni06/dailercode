const express = require('express');
const router = express.Router();

const listcallModule = require('../../modules/listcall/listcallController');
const listcallValidation = require('../../modules/listcall/listcallValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/getlistcall', authentication, listcallModule.getListcallName);
router.get('/getlistcallid', authentication, listcallModule.getListcallNamedetail);


router.post('/addlistcall', authentication,listcallValidation.sanitized, listcallValidation.validate,  listcallModule.postlistcall);
// router.get('/:id', /* authorization, */ themeModule.getPopupDetail);
router.get('/dellistcall', authentication, listcallModule.Deletelistcall);
router.get('/listcall-search', authentication, listcallModule.GetSearchlistcall);


module.exports = router;