const express = require('express');
const router = express.Router();

const cdrModule = require('../../modules/cdr/cdrController');
const cdrValidation = require('../../modules/cdr/cdrValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/getcdr', authentication, cdrModule.getcdr);
router.get('/getcdrid', authentication, cdrModule.getcdrDetail);
router.get('/search-cdr', authentication, cdrModule.searchcdr);


module.exports = router;