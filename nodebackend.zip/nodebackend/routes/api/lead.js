const express = require('express');
const router = express.Router();

const leadModule = require('../../modules/lead/leadController');
const leadValidation = require('../../modules/lead/leadValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/getlead', authentication, leadModule.getLeadName);
router.get('/getleadid', authentication, leadModule.getLeadNamedetail);
 router.post('/addlead', authentication,leadValidation.sanitized, leadValidation.validate,  leadModule.postlead);
 router.get('/dellead', authentication, leadModule.Deletelead);
 router.get('/lead-search', authentication, leadModule.GetleadSearch);
module.exports = router;