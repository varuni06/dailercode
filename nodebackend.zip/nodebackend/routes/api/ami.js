const express = require('express');
const router = express.Router();

const amiModule = require('../../modules/ami/amiController');
// const cdrValidation = require('../../modules/cdr/cdrValidation');
// const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/InitialSipCall',  amiModule.SipCall);
// router.get('/getcdrid', authentication, cdrModule.getcdrDetail);


module.exports = router;