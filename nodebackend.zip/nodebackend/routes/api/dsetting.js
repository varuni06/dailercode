const express = require('express');
const router = express.Router();

const dsettingModule = require('../../modules/dsetting/dsettingController');
const dsettingValidation = require('../../modules/dsetting/dsettingValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

// router.get('/getdsetting', authentication, dsettingModule.getdsetting);
// router.get('/getdsettingid', authentication, dsettingModule.getdsettingdetails);

router.get('/getdsetting', authentication, dsettingModule.getdsetting);
router.get('/getdsettingid', authentication, dsettingModule.getdsettingDetail);
router.post('/addsetting', authentication,dsettingValidation.sanitized, dsettingValidation.validate,  dsettingModule.postdsetting);
router.get('/deldsetting', authentication, dsettingModule.Deletedsetting);
router.get('/search-setting', authentication,dsettingModule.Searchsetting);

module.exports = router;