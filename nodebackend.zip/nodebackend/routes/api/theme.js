const express = require('express');
const router = express.Router();

const themeModule = require('../../modules/theme/themeController');
const themeValidation = require('../../modules/theme/themeValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/gettheme', authentication, themeModule.getThemeName);
 router.post('/addtheme', authentication,themeValidation.sanitized, themeValidation.validate,  themeModule.postTheme);
// router.get('/:id', /* authorization, */ themeModule.getPopupDetail);
router.delete('/deltheme', authentication, themeModule.DeleteTheme);

module.exports = router;
