const express = require('express');
const router = express.Router();

const campaignsModule = require('../../modules/campaigns/campaignsController');
const campaignsValidation = require('../../modules/campaigns/campaignsValidation');
const { authentication, authorization } = require('../../middleware/auth.middleware');

router.get('/getcampaigns', authentication, campaignsModule.getcampaigns);
router.get('/getcampaignsid', authentication, campaignsModule.getcampaignsdetail);
router.post('/addcampaigns', authentication,campaignsValidation.sanitized,campaignsValidation.validate, campaignsModule.postcampaigns);
router.get('/delcampaigns', authentication, campaignsModule.Deletecampaigns);
router.get('/campaign-search', authentication, campaignsModule.Getcampaignsearch);


module.exports = router;